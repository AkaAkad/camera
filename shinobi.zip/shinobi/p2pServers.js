{
    "vancouver-1": {
        name: 'Vancouver-1',
        host: 'p2p-vancouver-1.shinobi.cloud',
        p2pPort: '8084',
        webPort: '8000',
        maxNetworkSpeed: {
            up: 5000,
            down: 5000,
            shared: true
        },
        location: {
            lat: 49.284966,
            lon: -123.1140607
        }
    },
    "toronto-1": {
        name: 'Toronto-1',
        host: 'p2p-toronto-1.shinobi.cloud',
        p2pPort: '8084',
        webPort: '8000',
        maxNetworkSpeed: {
            up: 5000,
            down: 5000,
            shared: true
        },
        location: {
            lat: 43.644773,
            lon: -79.3862837
        }
    },
    "paris-1": {
        name: 'Paris-1',
        host: 'p2p-paris-1.shinobi.cloud',
        p2pPort: '8084',
        webPort: '8000',
        maxNetworkSpeed: {
            up: 200,
            down: 200,
            shared: true
        },
        location: {
            lat: 48.873877,
            lon: 2.295533
        }
    },
    "usa-1": {
        name: 'USA-1',
        host: 'p2p-usa-1.shinobi.cloud',
        p2pPort: '8084',
        webPort: '8000',
        maxNetworkSpeed: {
            up: 500,
            down: 500,
            shared: true
        },
        location: {
            lat: 52.348773,
            lon: 4.8846043
        }
    },
    "vancouver-1-v2": {
        name: 'Vancouver-1 (v2)',
        host: 'p2p-vancouver-1.shinobi.cloud',
        v2: true,
        p2pPort: '80',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 5000,
            down: 5000,
            shared: true
        },
        location: {
            lat: 49.284966,
            lon: -123.1140607
        }
    },
    "toronto-1-v2": {
        name: 'Toronto-1 (v2)',
        host: 'p2p-toronto-1.shinobi.cloud',
        v2: true,
        p2pPort: '80',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 5000,
            down: 5000,
            shared: true
        },
        location: {
            lat: 43.644773,
            lon: -79.3862837
        }
    },
    "paris-1-v2": {
        name: 'Paris-1 (v2)',
        host: 'p2p-paris-1.shinobi.cloud',
        v2: true,
        p2pPort: '80',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 200,
            down: 200,
            shared: true
        },
        location: {
            lat: 48.873877,
            lon: 2.295533
        }
    },
    "usa-1-v2": {
        name: 'USA-1 (v2)',
        host: 'p2p-usa-1.shinobi.cloud',
        v2: true,
        p2pPort: '80',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 500,
            down: 500,
            shared: true
        },
        location: {
            lat: 52.348773,
            lon: 4.8846043
        }
    },
    "vancouver-1-v2-ssl": {
        name: 'Vancouver-1 (v2, wss)',
        host: 'p2p-vancouver-1.shinobi.cloud',
        v2: true,
	  secure: true,
        p2pPort: '443',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 5000,
            down: 5000,
            shared: true
        },
        location: {
            lat: 49.284966,
            lon: -123.1140607
        }
    },
    "toronto-1-v2-ssl": {
        name: 'Toronto-1 (v2, wss)',
        host: 'p2p-toronto-1.shinobi.cloud',
        v2: true,
	  secure: true,
        p2pPort: '443',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 5000,
            down: 5000,
            shared: true
        },
        location: {
            lat: 43.644773,
            lon: -79.3862837
        }
    },
    "paris-1-v2-ssl": {
        name: 'Paris-1 (v2, wss)',
        host: 'p2p-paris-1.shinobi.cloud',
        v2: true,
	  secure: true,
        p2pPort: '443',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 200,
            down: 200,
            shared: true
        },
        location: {
            lat: 48.873877,
            lon: 2.295533
        }
    },
    "usa-1-v2-ssl": {
        name: 'USA-1 (v2, wss)',
        host: 'p2p-usa-1.shinobi.cloud',
        v2: true,
	  secure: true,
        p2pPort: '443',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 500,
            down: 500,
            shared: true
        },
        location: {
            lat: 52.348773,
            lon: 4.8846043
        }
    },
    "bangalore-1-v2-ssl": {
        name: 'Bangalore-1 (v2, wss)',
        host: 'p2p-bangalore-1.shinobi.cloud',
        v2: true,
	  secure: true,
        p2pPort: '443',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 500,
            down: 500,
            shared: true
        },
        location: {
            lat: 52.348773,
            lon: 4.8846043
        }
    },
    "sydney-1-v2-ssl": {
        name: 'Sydney-1 (v2, wss)',
        host: 'p2p-sydney-1.shinobi.cloud',
        v2: true,
	  secure: true,
        p2pPort: '443',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 500,
            down: 500,
            shared: true
        },
        location: {
            lat: 52.348773,
            lon: 4.8846043
        }
    },
    "singapore-1-v2-ssl": {
        name: 'Singapore-1 (v2, wss)',
        host: 'p2p-singapore-1.shinobi.cloud',
        v2: true,
	  secure: true,
        p2pPort: '443',
        webPort: '80',
        chartPort: '80',
        maxNetworkSpeed: {
            up: 500,
            down: 500,
            shared: true
        },
        location: {
            lat: 52.348773,
            lon: 4.8846043
        }
    },
}
